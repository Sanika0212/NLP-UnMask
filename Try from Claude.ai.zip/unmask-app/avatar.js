(function (global) {
  const STATES = ['idle','listening','thinking','speaking','asking','reveal','assess','celebrate','error'];
  const MARKUP = `
    <svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="UnMask">
      <circle data-p="ring1" cx="32" cy="32" r="26"></circle>
      <circle data-p="ring2" cx="32" cy="32" r="18"></circle>
      <circle data-p="ring3" cx="32" cy="32" r="10"></circle>
      <circle data-p="dot"   cx="32" cy="32" r="3.5"></circle>
    </svg>`;
  function mount(el, opts) {
    let initial = (opts && opts.initial) || 'idle';
    el.classList.forEach(c => { if (c.indexOf('state-') === 0) { initial = c.slice(6); el.classList.remove(c); } });
    el.classList.add('um-av');
    el.innerHTML = MARKUP;
    let current = initial;
    el.classList.add('state-' + current);
    function setState(next) {
      if (!STATES.includes(next) || next === current) return;
      el.classList.remove('state-' + current);
      void el.offsetWidth;
      el.classList.add('state-' + next);
      current = next;
    }
    function flash(n, ms) { const b = current; setState(n); setTimeout(()=>setState(b), ms||1500); }
    return { el, setState, flash, get state(){return current;} };
  }
  function autoMount(root) {
    (root || document).querySelectorAll('.um-av').forEach(el => {
      if (el.dataset.umMounted) return;
      mount(el);
      el.dataset.umMounted = '1';
    });
  }
  if (typeof document !== 'undefined') {
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => autoMount());
    else autoMount();
  }
  global.UMAvatar = { mount, autoMount, STATES };
})(typeof window !== 'undefined' ? window : this);
