/* UnMask candidate avatars — 4 variants × 9 states.
   Usage:
     <div class="um-av v-spark"></div>           // auto-mounts on load
     <div class="um-av v-rings state-thinking"></div>
   Or programmatic:
     const a = UMCandidates.mount(el, { variant: 'rings', initial: 'idle' });
     a.setState('reveal');
*/
(function (global) {
  const STATES = ['idle','listening','thinking','speaking','asking','reveal','assess','celebrate','error'];
  const VARIANTS = ['spark','rings','knot','cell'];

  const MARKUP = {
    spark: `
      <svg viewBox="0 0 64 64" fill="none" stroke="currentColor"
           xmlns="http://www.w3.org/2000/svg" role="img" aria-label="UnMask spark avatar">
        <circle data-p="halo" cx="32" cy="32" r="24" stroke-width="1.4"></circle>
        <g data-p="rays">
          <line data-p="ray" x1="32" y1="8"  x2="32" y2="22"></line>
          <line data-p="ray" x1="32" y1="42" x2="32" y2="56"></line>
          <line data-p="ray" x1="8"  y1="32" x2="22" y2="32"></line>
          <line data-p="ray" x1="42" y1="32" x2="56" y2="32"></line>
          <line data-p="ray" x1="14" y1="14" x2="24" y2="24"></line>
          <line data-p="ray" x1="40" y1="40" x2="50" y2="50"></line>
          <line data-p="ray" x1="50" y1="14" x2="40" y2="24"></line>
          <line data-p="ray" x1="14" y1="50" x2="24" y2="40"></line>
        </g>
        <circle data-p="core" cx="32" cy="32" r="5"></circle>
      </svg>
    `,
    rings: `
      <svg viewBox="0 0 64 64" fill="none"
           xmlns="http://www.w3.org/2000/svg" role="img" aria-label="UnMask rings avatar">
        <circle data-p="ring1" cx="32" cy="32" r="26"></circle>
        <circle data-p="ring2" cx="32" cy="32" r="18"></circle>
        <circle data-p="ring3" cx="32" cy="32" r="10"></circle>
        <circle data-p="dot"   cx="32" cy="32" r="3.5"></circle>
      </svg>
    `,
    knot: `
      <svg viewBox="0 0 64 64" fill="none"
           xmlns="http://www.w3.org/2000/svg" role="img" aria-label="UnMask knot avatar">
        <!-- Two rounded triangles, rotated 60deg from each other (Star of Lakshmi feel without it) -->
        <path data-p="loop1" d="M32 10 L52 44 L12 44 Z" stroke-linejoin="round"></path>
        <path data-p="loop2" d="M12 22 L52 22 L32 56 Z" stroke-linejoin="round"></path>
        <circle data-p="dot" cx="32" cy="33" r="3.2"></circle>
      </svg>
    `,
    cell: `
      <svg viewBox="0 0 64 64" fill="none"
           xmlns="http://www.w3.org/2000/svg" role="img" aria-label="UnMask cell avatar">
        <!-- Outer hex (flat-top), inner hex (rotated 30deg via path) -->
        <path data-p="hex"  d="M32 6 L54 19 L54 45 L32 58 L10 45 L10 19 Z"></path>
        <path data-p="hexI" d="M32 16 L46 24 L46 40 L32 48 L18 40 L18 24 Z"></path>
        <circle data-p="core" cx="32" cy="32" r="4"></circle>
      </svg>
    `
  };

  function mount(el, opts) {
    const variant = (opts && opts.variant)
      || VARIANTS.find(v => el.classList.contains('v-' + v))
      || 'spark';
    let initial = (opts && opts.initial) || 'idle';
    el.classList.forEach(c => { if (c.indexOf('state-') === 0) initial = c.slice(6); });
    el.classList.forEach(c => { if (c.indexOf('state-') === 0) el.classList.remove(c); });

    el.classList.add('um-av');
    if (!VARIANTS.some(v => el.classList.contains('v-' + v))) {
      el.classList.add('v-' + variant);
    }
    el.innerHTML = MARKUP[variant];
    let current = initial;
    el.classList.add('state-' + current);

    function setState(next) {
      if (!STATES.includes(next) || next === current) return;
      el.classList.remove('state-' + current);
      void el.offsetWidth;
      el.classList.add('state-' + next);
      current = next;
    }
    function flash(next, ms) {
      const before = current;
      setState(next);
      setTimeout(() => setState(before), ms || 1500);
    }
    return { el, setState, flash, get state() { return current; }, variant };
  }

  function autoMount(root) {
    (root || document).querySelectorAll('.um-av').forEach(el => {
      if (el.dataset.umMounted) return;
      mount(el);
      el.dataset.umMounted = '1';
    });
  }
  if (typeof document !== 'undefined') {
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => autoMount());
    else autoMount();
  }
  global.UMCandidates = { mount, autoMount, STATES, VARIANTS };
})(typeof window !== 'undefined' ? window : this);
