/* UnMask avatar — JS state-machine component.
   Usage:
     <div id="bot" class="unmask-avatar"></div>
     <script src="unmask-avatar.js"></script>
     <script>
       const bot = UnMaskAvatar.mount(document.getElementById('bot'));
       bot.setState('thinking');     // idle | listening | thinking | speaking | asking | reveal | assess | celebrate | error
       bot.flash('reveal', 1600);    // play a state for N ms then return to previous
     </script>
   Requires unmask-avatar.css on the page.
*/
(function (global) {
  const SVG_NS = 'http://www.w3.org/2000/svg';
  const STATES = ['idle','listening','thinking','speaking','asking','reveal','assess','celebrate','error'];

  const SVG_MARKUP = `
    <svg xmlns="${SVG_NS}" viewBox="0 0 64 64" role="img" aria-label="UnMask avatar"
         fill="none" stroke="currentColor" stroke-width="2"
         stroke-linecap="round" stroke-linejoin="round">
      <circle data-part="ring" cx="32" cy="32" r="26"></circle>
      <path   data-part="veil" d="M10 28 Q32 16 54 28"></path>
      <circle data-part="iris" cx="32" cy="34" r="9"></circle>
      <circle data-part="pupil" cx="32" cy="34" r="3" stroke="none"></circle>
      <path   data-part="highlight" d="M28 31.5 l1.6 -1.6" stroke-width="1.6"></path>
      <g      data-part="orbit">
        <circle cx="32" cy="28" r="1.4" fill="currentColor" stroke="none"></circle>
        <circle cx="36" cy="34" r="1.4" fill="currentColor" stroke="none"></circle>
        <circle cx="28" cy="34" r="1.4" fill="currentColor" stroke="none"></circle>
      </g>
    </svg>
  `;

  function mount(el, opts) {
    if (!el) throw new Error('UnMaskAvatar.mount: element required');
    el.classList.add('unmask-avatar');
    el.innerHTML = SVG_MARKUP;

    let current = (opts && opts.initial) || 'idle';
    let prev = current;
    let restoreTimer = null;
    el.classList.add('state-' + current);

    function setState(next) {
      if (!STATES.includes(next)) {
        console.warn('UnMaskAvatar: unknown state', next);
        return;
      }
      if (next === current) return;
      el.classList.remove('state-' + current);
      // Force reflow so animations restart cleanly
      void el.offsetWidth;
      el.classList.add('state-' + next);
      prev = current;
      current = next;
    }

    function flash(state, ms) {
      const before = current;
      if (restoreTimer) clearTimeout(restoreTimer);
      setState(state);
      restoreTimer = setTimeout(() => setState(before), ms || 1500);
    }

    return {
      el,
      setState,
      flash,
      get state() { return current; },
      states: STATES.slice()
    };
  }

  function autoMount(root) {
    const scope = root || document;
    const els = scope.querySelectorAll('.unmask-avatar');
    els.forEach(el => {
      if (el.dataset.umMounted) return;
      // Detect initial state from any existing state-* class
      let initial = 'idle';
      el.classList.forEach(c => {
        if (c.indexOf('state-') === 0) initial = c.slice(6);
      });
      // Strip then re-add via mount() so it's the single source of truth
      el.classList.forEach(c => { if (c.indexOf('state-') === 0) el.classList.remove(c); });
      mount(el, { initial });
      el.dataset.umMounted = '1';
    });
  }

  if (typeof document !== 'undefined') {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => autoMount());
    } else {
      autoMount();
    }
  }

  const api = { mount, autoMount, STATES };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  global.UnMaskAvatar = api;
})(typeof window !== 'undefined' ? window : this);
